import express from "express";
import {createUser, deleteUser,getUsers,  updateUser } from "../controllers/userController";

const userRoutes = express.Router();
userRoutes.get('/', getUsers);
userRoutes.post('/create', createUser);
userRoutes.put('/update/:_id', updateUser);
userRoutes.delete('/delete/:_id', deleteUser);

export default userRoutes;