import express from "express";
import { userLoginController } from "../controllers/noAuthController";
import { display } from "../controllers/defaultController";
const noAuthRouter = express.Router();
noAuthRouter.post('/login', userLoginController);
noAuthRouter.get('/hi',display);
export default noAuthRouter;