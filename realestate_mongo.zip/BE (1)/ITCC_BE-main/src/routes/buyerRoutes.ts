import express from "express";
import { getBuyers, createBuyer } from "../controllers/buyersController";

const buyersRoutes = express.Router();

buyersRoutes.get('/getbuyerdetails', getBuyers);
buyersRoutes.post('/create', createBuyer);
// buyersRoutes.put('/update/:_id', updateBuyer);
// buyersRoutes.delete('/delete/:_id', deleteBuyer);

export default buyersRoutes;
