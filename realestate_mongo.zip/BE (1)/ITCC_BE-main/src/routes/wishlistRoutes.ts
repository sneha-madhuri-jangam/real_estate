

import express from "express";
// import { getBuyers, createBuyer } from "../controllers/buyersController";
import {addToWishlist,
    getWishlist} from "../controllers/wishList";

const wishlistRoutes = express.Router();

wishlistRoutes.get('/getwishList',getWishlist);
wishlistRoutes.post('/addtowishList',addToWishlist);
// buyersRoutes.put('/update/:_id', updateBuyer);
// buyersRoutes.delete('/delete/:_id', deleteBuyer);

export default wishlistRoutes;
