import bodyParser from "body-parser";
import cors from "cors";
import express from "express";
import mongoose from "mongoose";
import userRoutes from "./routes/userRoute";
import buyersRoutes from "./routes/buyerRoutes";
import wishlistRoutes from "./routes/wishlistRoutes";
import 'dotenv/config'
import noAuthRouter from "./routes/noAuthRoutes";
import { verifyJwt } from "./services/jwtAuthService";





const app = express();
app.use(cors({
  origin: '*',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.options('*', cors());
app.use(bodyParser.json())
app.use('/', noAuthRouter);
app.use('/users',verifyJwt, userRoutes);
app.use('/buyers', buyersRoutes);
app.use('/wishlist',wishlistRoutes);


mongoose.connect("mongodb+srv://ITCC:x3txwwBMqr1bQZnR@atlascluster.30o4fpw.mongodb.net/RealEstate?retryWrites=true&w=majority&appName=AtlasCluster").then(() => {
  console.log("DB Connected");
  app.listen(3002, () => {
    console.log("Server started on port 3002");
  })
}).catch((e) => {
  console.log(e);
});