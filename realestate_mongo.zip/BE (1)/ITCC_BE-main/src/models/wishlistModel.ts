import mongoose from "mongoose";

const wishlistSchema = new mongoose.Schema({
 propertyName: {
        type: String,
        required: true,
 },
 Location: {
    type: String,
    // match: /^[0-9]{10}$/,
    required: true,
 },
 OwnerName: {
    type: String,
    trim: true,
    unique: true,
    // match: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
    required: true,
 },
 size:{
    units:{
        type:Number
    },
    acres:{
        type:Number

    },
    cents:{
        type:Number

    }

 },
 distance:{
    type:Number
 },

 litigation : {
  type: Boolean,
 },

 price:{
    String : Number
 },

 amenities: {
    boreWells:{
        type:Boolean,
        
    },
    electriCity:{
        type:Boolean,
    }
  },

 features: {
   type: String,
 },

  yearofCon: {
type: Number,
},

reSale:{
    type:Boolean,
},

propertyImages: {
    type: String
}

});
export const wishlistModel = mongoose.model("wishlist", wishlistSchema);