import { Request, Response } from "express";
import { userModel } from "../models/userModel";
import { generatePassword, sendUserCredentials } from "../services/userService";
const getUsers = async (req: Request, res: Response) => {
    let data = await userModel.find()
    res.send(data)
}
const createUser = async (req: Request, res: Response) => {
    try {
        let user = new userModel({...req.body});
        user.save().then(() => {
            res.send({ message: "User Added Successfully", success: true });
        }).catch(error =>
            res.status(400).send(error)
        )
    }
    catch (error) {
        res.status(500).send(error);
    }
}
const updateUser = async (req: Request, res: Response) => {
    try {
        const userId = req.params._id;
        const updateData = req.body;
        let user = await userModel.findByIdAndUpdate(userId, updateData, { new: true, runValidators: true });
        if (!user) {
            return res.status(404).send({ message: "User not found", success: false });
        }
        res.send({ message: "User Updated Successfully", success: true, user });
    } catch (error) {
        res.status(500).send(error);
    }
}
const deleteUser = async (req: Request, res: Response) => {
    try {
        const userId = req.params._id;
        let user = await userModel.findByIdAndDelete(userId);
        if (!user) {
            return res.status(404).send({ message: "User not found", success: false });
        }
        res.send({ message: "User Deleted Successfully", success: true });
    } catch (error) {
        res.status(500).send(error);
    }
}



export {
    createUser,
    deleteUser,
    getUsers,
    updateUser,
 userModel
};

