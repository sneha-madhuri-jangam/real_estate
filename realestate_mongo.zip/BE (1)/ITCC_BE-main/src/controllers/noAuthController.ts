import { Request, Response } from "express";
import { userModel } from "../models/userModel";
import jsonwebtoken from "jsonwebtoken";
const userLoginController = async (req: Request, res: Response) => {
    try {
        let { email, password } = req.body;
        let data = await userModel.findOne({ email, password });
        console.log(data);
        if (data != null) {
            let { email, role, _id: userId, firstName } = data;
            const token = jsonwebtoken.sign({ email, role, userId, firstName }, "secretKey");
            res.send({ success: true, token });
        }
        else {
            res.status(400).send({ message: "Invalid credentials", success: false });
        }
    }
    catch (error) {
        console.log(error);
        res.status(500).send(error);
    }
}



export { userLoginController};