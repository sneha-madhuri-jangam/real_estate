import { Request, Response } from "express";
import { buyersModel } from "../models/buyersModel";

// Get all buyers
const display = (req: Request, res: Response) => {
    try {
       console.log("hello");
        res.status(200).json("hello");
    } catch (error) {
        res.status(500).json({ message: "Error fetching buyers", error });
    }
};

export {
    // getBuyers
    display
}